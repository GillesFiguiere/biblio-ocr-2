# biblio-ionic
Développez une application mobile multiplateforme avec Ionic - TP 1

# Installation
1. git clone https://github.com/GillesOpenClassRoom/biblio-ionic.git
2. cd biblio-ionic
3. npm install

# Démarrage
ionic serve
